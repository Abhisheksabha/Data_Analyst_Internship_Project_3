CREATE DATABASE zomato;
USE zomato;

-- 1 . Build a Calendar Table using the Columns Datekey_Opening ( Which has Dates from Minimum Dates and Maximum Dates)
-- Add all the below Columns in the Calendar Table using the Formulas.

ALTER TABLE main
ADD COLUMN Year INT,
ADD COLUMN Monthno INT,
ADD COLUMN Monthfullname VARCHAR(20),
ADD COLUMN Quarter VARCHAR(2),
ADD COLUMN YearMonth VARCHAR(12),
ADD COLUMN Weekdayno INT,
ADD COLUMN Weekdayname VARCHAR(20),
ADD COLUMN FinancialMOnth CHAR(20),
ADD COLUMN FinancialQuarter VARCHAR(3);

  UPDATE main SET
  Year = YEAR(Datekey_Opening),
  Monthno = MONTH(Datekey_Opening),
  Monthfullname = MONTHNAME(Datekey_Opening),
  Quarter =CONCAT('Q', QUARTER(Datekey_Opening)),
  YearMonth=DATE_FORMAT(Datekey_Opening, '%Y-%b'),
  Weekdayno=DAYOFWEEK(Datekey_Opening),
  Weekdayname=DAYNAME(Datekey_Opening),
  FinancialMOnth=CASE WHEN MONTH(Datekey_Opening) >= 4 THEN CONCAT('FM', MONTH(Datekey_Opening) - 3)
  ELSE CONCAT('FM', MONTH(Datekey_Opening) + 9) END,
  FinancialQuarter = CONCAT('FQ', CASE WHEN MONTH(Datekey_Opening) >= 4 THEN CEIL((MONTH(Datekey_Opening) - 3) / 3)
  ELSE CEIL((MONTH(Datekey_Opening) + 9) / 3) END);

  
SET SQL_SAFE_UPDATES = 0;
SELECT * FROM main;


-- 3.Convert the Average cost for 2 column into USD dollars 
-- (currently the Average cost for 2 in local currencies

SELECT m.average_cost_for_two * c.`USD Rate` AS average_cost_for_2_usd
FROM main m JOIN currencies c ON m.currency = c.currency;

ALTER TABLE main MODIFY COLUMN average_cost_for_2_usd DECIMAL(10, 2);

UPDATE main m
JOIN currencies c ON m.currency = c.currency
SET m.average_cost_for_2_usd = CAST(m.average_cost_for_two * c.`USD Rate` AS DECIMAL(10, 2));


-- 4.Find the Numbers of Resturants based on City and Country.

SELECT m.city, c.countryName, COUNT(*) AS restaurant_count
FROM main m 
JOIN Countries c ON m.countrycode = c.countrycode
GROUP BY m.city, c.countryName
ORDER BY restaurant_count DESC;

-- 5.Numbers of Resturants opening based on Year , Quarter , Month

SELECT YEAR, QUARTER, Monthfullname AS Month,
COUNT(*) AS restaurant_count FROM main
GROUP BY year, quarter, Month
ORDER BY year, quarter, Month;

-- 6. Count of Resturants based on Average Ratings

SELECT AVG(Rating), COUNT(*) AS restaurant_count 
FROM main
GROUP BY Rating  
ORDER BY AVG(rating);

-- 7. Create buckets based on Average Price of reasonable size and find out how many resturants falls in each buckets
 
 SELECT CASE WHEN average_cost_for_2_usd BETWEEN 1 AND 19.99 THEN '1$-19.99$'
 WHEN average_cost_for_2_usd BETWEEN 20 AND 39.99 THEN '20$-39.99$'
 WHEN average_cost_for_2_usd BETWEEN 40 AND 59.99 THEN '40$-59.99$'
 WHEN average_cost_for_2_usd >= 60 THEN 'Above 60$' END AS price_bucket,
 COUNT(*) AS restaurant_count FROM main
GROUP BY price_bucket
ORDER BY price_bucket DESC;

-- 8.Percentage of Resturants based on "Has_Table_booking"

SELECT Has_Table_booking, COUNT(*) AS restaurant_count,
CONCAT(ROUND((COUNT(*) * 100.0 / (SELECT COUNT(*) FROM main)), 2), '%') 
AS percentage FROM main
GROUP BY Has_Table_booking;

-- 9.Percentage of Resturants based on "Has_Online_delivery"

SELECT Has_Online_delivery, COUNT(*) AS restaurant_count,
CONCAT(ROUND((COUNT(*) * 100.0 / (SELECT COUNT(*) FROM main)), 2), '%') AS percentage
FROM main GROUP BY Has_Online_delivery;


-- 10. Top 5 Restaurants By cities

SELECT city, COUNT(*) AS restaurant_count
FROM main GROUP BY city ORDER BY
restaurant_count DESC LIMIT 5;

-- 11. Top 5 cuisines by restaurants

SELECT cuisines, COUNT(*) AS restaurant_count
FROM main GROUP BY cuisines ORDER BY 
restaurant_count DESC LIMIT 5;

-- 12.Number of restaurants opening based on year

SELECT YEAR, COUNT(*) AS Restaurant_count
FROM main GROUP BY YEAR
ORDER BY Year;

 























	